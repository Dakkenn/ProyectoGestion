/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package proyectogestion;



/**
 *
 * @author Duoc
 */


import java.time.LocalDate;
import java.util.Scanner;

public class ProyectoGestion {

    public static void main(String[] args) {
        try (Scanner sc = new Scanner(System.in)) {
            Cliente cliente = null;
            Vendedor vendedor = null;
            Producto producto = null;
            Pedido pedido = null;
            
            int opcion;
            do {
                System.out.println("\n--- MENÚ ---");
                System.out.println("1. Ingresar Cliente");
                System.out.println("2. Ingresar Vendedor");
                System.out.println("3. Ingresar Producto");
                System.out.println("4. Generar Pedido");
                System.out.println("5. Salir");
                System.out.print("Seleccione opción: ");
                opcion = sc.nextInt();
                sc.nextLine(); // limpiar buffer
                
                switch (opcion) {
                    case 1 -> {
                        System.out.print("RUT Cliente: ");
                        String rut = sc.nextLine();
                        System.out.print("Nombre Cliente: ");
                        String nombre = sc.nextLine();
                        System.out.print("Edad Cliente: ");
                        int edad = sc.nextInt();
                        sc.nextLine();
                        System.out.print("Fecha de nacimiento (AAAA-MM-DD): ");
                        String fechaStr = sc.nextLine();
                        LocalDate fechaNacimiento = LocalDate.parse(fechaStr);
                        cliente = new Cliente(rut, nombre, edad, fechaNacimiento);
                        System.out.println("Cliente ingresado con éxito.");
                        
                    }
                        
                    case 2 -> {
                        System.out.print("RUT Vendedor: ");
                        String rutV = sc.nextLine();
                        System.out.print("Nombre Vendedor: ");
                        String nombreV = sc.nextLine();
                        vendedor = new Vendedor(rutV, nombreV);
                        System.out.println("Vendedor ingresado con éxito.");
                    }
                        
                    case 3 -> {
                        System.out.print("Código Producto: ");
                        String codigo = sc.nextLine();
                        System.out.print("Nombre Producto: ");
                        String nombreP = sc.nextLine();
                        System.out.print("Tipo Producto: ");
                        String tipo = sc.nextLine();
                        System.out.print("Precio Unitario: ");
                        int precio = sc.nextInt();
                        sc.nextLine();
                        producto = new Producto(codigo, nombreP, tipo, precio);
                        System.out.println("Producto ingresado con éxito.");
                    }
                        
                    case 4 -> {
                        if (cliente == null || vendedor == null || producto == null) {
                            System.out.println("Debe ingresar cliente, vendedor y producto primero.");
                        } else {
                            System.out.print("Cantidad a pedir: ");
                            int cantidad = sc.nextInt();
                            sc.nextLine();
                            
                            pedido = new Pedido(cliente, producto, vendedor, cantidad, LocalDate.now());
                            
                            System.out.println("\n--- RESUMEN PEDIDO ---");
                            System.out.println("Cliente: " + cliente.getNombreCliente());
                            System.out.println("Producto: " + producto.getNombreProducto());
                            System.out.println("Cantidad: " + cantidad);
                            System.out.println("Bruto: " + pedido.calcularBruto());
                            System.out.println("Total con descuento: " + pedido.calculartotalBruto());
                        }
                    }
                        
                    case 5 -> System.out.println("Saliendo del programa...");
                        
                    default -> System.out.println("Opción no válida.");
                }
                
            } while (opcion != 5);
        }
    }
}
