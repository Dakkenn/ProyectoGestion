/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package proyectogestion;


/**
 *
 * @author Duoc
 */

import java.time.LocalDate;

public class Pedido {
    private Cliente cliente;
    private Producto producto;
    private Vendedor vendedor;
    private Integer cantidad;
    private LocalDate fechaPedido;

    public Pedido(Cliente cliente, Producto producto, Vendedor vendedor, Integer cantidad, LocalDate fechaPedido) {
        this.cliente = cliente;
        this.producto = producto;
        this.vendedor = vendedor;
        this.cantidad = cantidad;
        this.fechaPedido = fechaPedido;
    }

    public Cliente getCliente() {
        return cliente;
    }

    public void setCliente(Cliente cliente) {
        this.cliente = cliente;
    }

    public Producto getProducto() {
        return producto;
    }

    public void setProducto(Producto producto) {
        this.producto = producto;
    }

    public Vendedor getVendedor() {
        return vendedor;
    }

    public void setVendedor(Vendedor vendedor) {
        this.vendedor = vendedor;
    }

    public Integer getCantidad() {
        return cantidad;
    }

    public void setCantidad(Integer cantidad) {
        this.cantidad = cantidad;
    }

    public LocalDate getFechaPedido() {
        return fechaPedido;
    }

    public void setFechaPedido(LocalDate fechaPedido) {
        this.fechaPedido = fechaPedido;
    }
    
    public Integer calcularBruto(){
        return producto.getPrecioUnitario() * cantidad;
    }
    
    public double calculartotalBruto() {
    double bruto = calcularBruto();
    double total = bruto;

    // Descuento por monto
    if (bruto > 120000) {
        total = total * 0.75;   // 25% de descuento
    } else if (bruto > 60000) {
        total = total * 0.85;   // 15% de descuento
    }

    // Descuento adicional por edad
    if (cliente.getEdad() > 65) {
        total = total * 0.5;    // 50% adicional
    }

    return total;
}


    
    
    public boolean  validarEstadoPedido(Cliente cliente){
        if (cliente.getEdad() >= 18){
            System.out.println("Cliente mayor de edad - Pedido Confirmado");
            return true;
        }else {
            System.out.println("Pedido invalido, Cliente es menor de edad (18 años)");
            return false;
        }
    }
    
    public boolean validarPedido() {
        // VALIDACIÓN 1: Edad del cliente (debe ser entre 18 y 79 años)
        int edadCliente = cliente.getEdad(); // Obtengo la edad del cliente
        
        if (edadCliente < 18) {
            // El cliente es menor de 18 años
            System.out.println("Error: Cliente es menor de edad (" + edadCliente + " años)");
            return false; // Pedido NO válido
        }
        
        if (edadCliente >= 80) {
            // El cliente tiene 80 años o más
            System.out.println("Error: Cliente excede edad máxima (" + edadCliente + " años)");
            return false; // Pedido NO válido
        }
        
        // VALIDACIÓN 2: Nombre del cliente no debe estar vacío
        String nombreCliente = cliente.getNombre(); // Obtengo el nombre del cliente
        
        if (nombreCliente == null || nombreCliente.trim().isEmpty()) {
            // El nombre está vacío o es null
            System.out.println("Error: El nombre del cliente no puede estar vacío");
            return false; // Pedido NO válido
        }
        
        // VALIDACIÓN 3: Nombre del vendedor no debe estar vacío
        String nombreVendedor = vendedor.getNombre(); // Obtengo el nombre del vendedor
        
        if (nombreVendedor == null || nombreVendedor.trim().isEmpty()) {
            // El nombre está vacío o es null
            System.out.println("Error: El nombre del vendedor no puede estar vacío");
            return false; // Pedido NO válido
        }
        return false;
    
    }

    
}

